var http = require('http') ;
var url = require('url') ;

var monServeur=function(requete, reponse){
  var page = url.parse(requete.url).pathname ;
  reponse.writeHead(200,{"Content-Type": "text/plain; charset=UTF-8"}) ;
  console.log("Le serveur est à l'écoute sur le port 8888");
  switch(page){
    case '/' : reponse.end("Vous êtes sur la page d'accueil"); break ;
    default : reponse.end('Ce cas ne devrait pas arriver') ;
  }
}

var serveur = http.createServer(monServeur) ;

serveur.listen(8888) ;