// app.js

var express = require('express') ;
var app = express() ;
app.set ('view-engine', 'ejs') ;
var port = 8888 ;

app.get('/:objet/:param/:valeur', function(req, res){
    res.render('page.ejs', {"objet": req.params.objet, "param": req.params.param, "valeur": req.params.valeur}) ;
    //res.send('Ceci est la page '+req.params.objet+req.params.param) ;
}) ;

app.use(function(req, res, next){
    //la ligne suivante spécifie l'encodage de la réponse
    res.setHeader('Content-Type', 'text/plain; charset=UTF-8') ;
    //La ligne suivante spécifie le message à envoyer par le serveur quand la réponse est un code d'erreur 404
    res.status(404).send("Cette page n'existe pas") ;
}) 

app.listen(port, function(){
  console.log('Le serveur fonctionne sur le port '+port) ;
})
