// app.js

var express = require('express') ;
var app = express() ;
var port = 8888 ;

app.get('/', function(req, res){
    res.send('Bonjour tout le monde') ;
}) ;

app.use(function(req, res, next){
    //la ligne suivante spécifie l'encodage de la réponse
    res.setHeader('Content-Type', 'text/plain; charset=UTF-8') ;
    //La ligne suivante spécifie le message à envoyer par le serveur quand la réponse est un code d'erreur 404
    res.status(404).send("Cette page n'existe pas") ;
}) 

app.listen(port, function(){
  console.log('Le serveur fonctionne sur le port '+port) ;
})
